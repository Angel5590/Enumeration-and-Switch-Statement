import UIKit

enum CompassPoint {
    case mayo
    case meat
    case cheese
    case vegtables
    }
